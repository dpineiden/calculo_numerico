y=77e3;
L=1000;
s=1100;
B=fzero('(1/x)*sinh(x)-s/L',2);
