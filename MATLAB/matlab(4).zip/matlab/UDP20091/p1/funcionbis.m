syms x;
f=x^3-3.23*x^2-5.54*x+9.84;
factor(f);
fx=[1,-3.23,-5.54,9.84];
xx=roots(fx)