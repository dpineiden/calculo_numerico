function Q=qsor(A,metodo)
[L D U]=jacobildu(A);
C=-L;
Tgs=0;
%metodo =1: jacobi
%metodo =2: gauus siedel
if metodo==1
Tgs=D^-1*(C+C');
elseif metodo==2
Tgs=(D-C)^-1*C;
end
w=2/(1+sqrt(1-norm(Tgs,inf)));
Q=(1/w)*D-C;