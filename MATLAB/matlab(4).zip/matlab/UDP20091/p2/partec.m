%calculo error Jacobi
Hj(1)=norm(T1-jx1,inf)/norm(T1,inf);
Hj(2)=norm(T2-jx2,inf)/norm(T2,inf);
Hj(3)=norm(T3-jx3,inf)/norm(T3,inf);
Hj(4)=norm(T4-jx4,inf)/norm(T4,inf);
Hj(5)=norm(T5-jx5,inf)/norm(T5,inf);

%calculo error gausssiedel
Hg(1)=norm(T1-gs1,inf)/norm(T1,inf);
Hg(2)=norm(T2-gs2,inf)/norm(T2,inf);
Hg(3)=norm(T3-gs3,inf)/norm(T3,inf);
Hg(4)=norm(T4-gs4,inf)/norm(T4,inf);
Hg(5)=norm(T5-gs5,inf)/norm(T5,inf);


%calculo error SOR
Hs(1)=norm(T1-sor1,inf)/norm(T1,inf);
Hs(2)=norm(T2-sor2,inf)/norm(T2,inf);
Hs(3)=norm(T3-sor3,inf)/norm(T3,inf);
Hs(4)=norm(T4-sor4,inf)/norm(T4,inf);
Hs(5)=norm(T5-sor5,inf)/norm(T5,inf);

logHj=log10(Hj);
logHg=log10(Hg);
logHs=log10(Hs);