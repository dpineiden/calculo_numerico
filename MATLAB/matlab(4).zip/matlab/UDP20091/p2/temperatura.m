clear all
%condiciones iniciales
syms x;
%xn=0
To=0;
%xn=L
TL=37;
%ctes
k=1;
%1 m
L=1;
%funcion
f='37*(pi/2)^2 * sin(pi/2*x)';
N1=3;
h(1)=L/(N1+1);
xo1=[0:h(1):L]';
x=xo1;
F1(:,1)=eval(f);
to1=[To;zeros(N1,1);TL];
TX1=h(1)*h(1)*F1+to1;
A1=matriza(N1+2);
%solución algebraica
T1=A1^-1*TX1;
%matriz Q para J, Jacobi y GaussSiedel
Qj1=2*ones(5);
%Sor
Qs1=qsor(A1,1);

N2=8;
h(2)=L/(N2+1);
xo2=[0:h(2):L]';
x=xo2;
F2(:,1)=eval(f);
to2=[To;zeros(N2,1);TL];
TX2=h(2)*h(2)*F2+to2;
A2=matriza(N2+2);
%solución algebraica
T2=A2^-1*TX2;
%matriz Q para J, Jacobi y GaussSiedel
Qj2=2*ones(10);
%Sor
Qs2=qsor(A2,1);

N3=18;
h(3)=L/(N3+1);
xo3=[0:h(3):L]';
x=xo3;
F3(:,1)=eval(f);
to3=[To;zeros(N3,1);TL];
TX3=h(3)*h(3)*F3+to3;
A3=matriza(N3+2);
%solución algebraica
T3=A3^-1*TX3;
%matriz Q para J, Jacobi y GaussSiedel
Qj3=2*ones(20);
%Sor
Qs3=qsor(A3,1);

N4=38;
h(4)=L/(N4+1);
xo4=[0:h(4):L]';
x=xo4;
F4(:,1)=eval(f);
to4=[To;zeros(N4,1);TL];
TX4=h(4)*h(4)*F4+to4;
A4=matriza(N4+2);
%solución algebraica
T4=A4^-1*TX4;
%matriz Q para J, Jacobi y GaussSiedel
Qj4=2*ones(40);
%Sor
Qs4=qsor(A4,1);

N5=78;
h(5)=L/(N5+1);
xo5=[0:h(5):L]';
x=xo5;
F5(:,1)=eval(f);
to5=[To;zeros(N5,1);TL];
TX5=h(5)*h(5)*F5+to5;
A5=matriza(N5+2);
%solución algebraica
T5=A5^-1*TX5;
%matriz Q para J, Jacobi y GaussSiedel
Qj5=2*ones(80);
%Sor
Qs5=qsor(A5,1);

xo1=.88*T1;
xo2=.5*T2;
xo3=.82*T3;
xo4=1.012*T4;
xo5=1.05*T5;
%Se hace el calculo, por metodo y valor de N
%con un maximo de iteraciones
n=10000;
%condiciones iniciales


[jx1,no(1,1)]=jacobi(A1,TX1,xo1,n,h(1));
[jx2,no(1,2)]=jacobi(A2,TX2,xo2,n,h(2));
[jx3,no(1,3)]=jacobi(A3,TX3,xo3,n,h(3));
[jx4,no(1,4)]=jacobi(A4,TX4,xo4,n,h(4));
[jx5,no(1,5)]=jacobi(A5,TX5,xo5,n,h(5));



[gs1,no(2,1)]=gausssiedel(A1,TX1,xo1,n,h(1));
[gs2,no(2,2)]=gausssiedel(A2,TX2,xo2,n,h(2));
[gs3,no(2,3)]=gausssiedel(A3,TX3,xo3,n,h(3));
[gs4,no(2,4)]=gausssiedel(A4,TX4,xo4,n,h(4));
[gs5,no(2,5)]=gausssiedel(A5,TX5,xo5,n,h(5));




[sor1,no(3,5)]=relajacionsucesiva(A1,TX1,xo1,n,h(1));
[sor2,no(3,5)]=relajacionsucesiva(A2,TX2,xo2,n,h(2));
[sor3,no(3,5)]=relajacionsucesiva(A3,TX3,xo3,n,h(3));
[sor4,no(3,5)]=relajacionsucesiva(A4,TX4,xo4,n,h(4));
[sor5,no(3,5)]=relajacionsucesiva(A5,TX5,xo5,n,h(5));



SOL=[jx1 jx1 jx1 jx1 jx1;gs1 gs1 gs1 gs1 gs1; sor1 sor1 sor1 sor1 sor1];


%parte c
% solucion analítica
T1;
T2;
T3;
T4;
T5;



